package dto;

public class perChatviewMemberDto {
	private int memberIdx;

	public perChatviewMemberDto(int memberIdx) {
		super();
		this.memberIdx = memberIdx;
	}

	public int getMemberIdx() {
		return memberIdx;
	}

	public void setMemberIdx(int memberIdx) {
		this.memberIdx = memberIdx;
	}

}
