package dto;

public class ChatNumDto {
	private int chatIdx;
	public ChatNumDto(int chatIdx) {
		this.chatIdx = chatIdx;
	}
	public int getChatIdx() {
		return chatIdx;
	}
	public void setChatIdx(int chatIdx) {
		this.chatIdx = chatIdx;
	}
	

}
